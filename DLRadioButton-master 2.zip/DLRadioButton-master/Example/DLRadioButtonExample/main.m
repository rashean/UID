//
//  main.m
//  DLRadioButtonExample
//
//  Created by Liu, Xingruo on 8/22/14.
//  Copyright (c) 2014 Xingruo Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DLAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DLAppDelegate class]));
    }
}
