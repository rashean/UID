//
//  DLAppDelegate.h
//  DLRadioButtonExample
//
//  Created by Liu, Xingruo on 8/22/14.
//  Copyright (c) 2014 Xingruo Liu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
